package com.example.travel

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.example.travel.ui.theme.TravelTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class LoginActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TravelTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    LoginScreen(
                        modifier = Modifier.padding(innerPadding),
                        onRegisterClick = {
                            startActivity(Intent(this, RegisterActivity::class.java))
                        },
                        onForgotPasswordClick = {
                            // startActivity(Intent(this, ForgotPasswordActivity::class.java))
                            Toast.makeText(this, "功能暂未开放", Toast.LENGTH_SHORT).show()
                        },
                        onLoginClick = { account, password, isSmsMode, smsCode ->
                            lifecycleScope.launch {
                                try {
                                    val request = if (isSmsMode) {
                                        if (account.isEmpty() || smsCode.isEmpty()) {
                                            Toast.makeText(this@LoginActivity, "请输入手机号和验证码", Toast.LENGTH_SHORT).show()
                                            return@launch
                                        }
                                        LoginRequest(account = account, smsCode = smsCode)
                                    } else {
                                        if (account.isEmpty() || password.isEmpty()) {
                                            Toast.makeText(this@LoginActivity, "请输入账号和密码", Toast.LENGTH_SHORT).show()
                                            return@launch
                                        }
                                        LoginRequest(account = account, password = password)
                                    }

                                    val response = NetworkClient.apiService.login(request)

                                    if (response.success && response.data != null) {
                                        val authData = response.data
                                        NetworkClient.userToken = authData.token
                                        Toast.makeText(this@LoginActivity, "登录成功", Toast.LENGTH_SHORT).show()
                                        
                                        if (authData.role == "ADMIN") {
                                            startActivity(Intent(this@LoginActivity, AdminActivity::class.java))
                                        } else {
                                            startActivity(Intent(this@LoginActivity, HomeActivity::class.java))
                                        }
                                        finish()
                                    } else {
                                        Toast.makeText(this@LoginActivity, "登录失败: ${response.message}", Toast.LENGTH_LONG).show()
                                    }
                                } catch (e: Exception) {
                                    Log.e("LoginActivity", "Network error: ${e.message}", e)
                                    Toast.makeText(this@LoginActivity, "网络异常", Toast.LENGTH_LONG).show()
                                }
                            }
                        },
                        onSendSmsClick = { phone ->
                            if (phone.isEmpty()) {
                                Toast.makeText(this, "请输入手机号", Toast.LENGTH_SHORT).show()
                                return@LoginScreen
                            }
                            lifecycleScope.launch {
                                try {
                                    val response = NetworkClient.apiService.sendSms(SmsSendRequest(phone = phone))
                                    if (response.success && response.data != null) {
                                        // 弹窗显示验证码（仅限开发测试环境方便查看）
                                        val toast = Toast.makeText(this@LoginActivity, "验证码已发送: ${response.data.smsCode}", Toast.LENGTH_LONG)
                                        toast.show()
                                        launch {
                                            delay(5000)
                                            toast.cancel()
                                        }
                                    } else {
                                        Toast.makeText(this@LoginActivity, "发送失败: ${response.message}", Toast.LENGTH_SHORT).show()
                                    }
                                } catch (e: Exception) {
                                    Toast.makeText(this@LoginActivity, "网络异常", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun LoginScreen(
    modifier: Modifier = Modifier,
    onRegisterClick: () -> Unit,
    onForgotPasswordClick: () -> Unit,
    onLoginClick: (String, String, Boolean, String) -> Unit,
    onSendSmsClick: (String) -> Unit
) {
    var account by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var smsCode by remember { mutableStateOf("") }
    var isSmsMode by remember { mutableStateOf(false) }

    Column(
        modifier = modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .background(Color(0xFF1A56DB))
        )
        Spacer(modifier = Modifier.height(60.dp))
        Text(text = "旅游书", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1A56DB))
        Spacer(modifier = Modifier.height(40.dp))
        Text(text = "登录", fontSize = 24.sp, fontWeight = FontWeight.SemiBold)

        Spacer(modifier = Modifier.height(30.dp))

        // 验证方式选择
        Row(
            modifier = Modifier.fillMaxWidth(0.8f),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            CustomRadioButton(selected = !isSmsMode, label = "密码验证", onClick = { isSmsMode = false })
            Spacer(modifier = Modifier.width(30.dp))
            CustomRadioButton(selected = isSmsMode, label = "短信验证", onClick = { isSmsMode = true })
        }

        Spacer(modifier = Modifier.height(30.dp))

        if (!isSmsMode) {
            // 密码验证模式
            OutlinedTextField(
                value = account,
                onValueChange = { account = it },
                label = { Text("手机号 / 账号") },
                modifier = Modifier.fillMaxWidth(0.8f)
            )

            Spacer(modifier = Modifier.height(15.dp))
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("密码") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth(0.8f)
            )
        } else {
            // 短信验证模式
            OutlinedTextField(
                value = account,
                onValueChange = { account = it },
                label = { Text("手机号") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier.fillMaxWidth(0.8f)
            )

            Spacer(modifier = Modifier.height(15.dp))
            Row(
                modifier = Modifier.fillMaxWidth(0.8f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = smsCode,
                    onValueChange = { smsCode = it },
                    label = { Text("验证码") },
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Button(
                    onClick = { onSendSmsClick(account) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1A56DB)),
                    modifier = Modifier.height(56.dp)
                ) {
                    Text("发送短信", fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(15.dp))
        Row(modifier = Modifier.fillMaxWidth(0.8f), horizontalArrangement = Arrangement.End) {
            TextButton(onClick = onForgotPasswordClick) {
                Text(text = "忘记密码", fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))
        Button(
            onClick = { onLoginClick(account, password, isSmsMode, smsCode) },
            modifier = Modifier.fillMaxWidth(0.8f),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1A56DB))
        ) {
            Text(text = "登录", fontSize = 16.sp)
        }

        Spacer(modifier = Modifier.height(20.dp))
        TextButton(onClick = onRegisterClick) {
            Text(text = "还没有账号？立即注册", fontSize = 14.sp)
        }
    }
}

@Composable
fun CustomRadioButton(selected: Boolean, label: String, onClick: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .size(20.dp)
                .border(2.dp, if (selected) Color(0xFF1A56DB) else Color.Gray, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (selected) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .background(Color(0xFF1A56DB), CircleShape)
                )
            }
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = label, fontSize = 16.sp, color = if (selected) Color(0xFF1A56DB) else Color.Gray)
    }
}
