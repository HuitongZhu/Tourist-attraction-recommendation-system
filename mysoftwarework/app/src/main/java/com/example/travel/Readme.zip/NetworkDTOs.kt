package com.example.travel

/**
 * 后端统一返回格式
 */
data class ApiResponse<T>(
    val success: Boolean,
    val message: String,
    val data: T?
)

/**
 * 分页响应格式
 */
data class PageResponse<T>(
    val content: List<T>,
    val page: Int,
    val size: Int,
    val totalElements: Long,
    val totalPages: Int
)

/**
 * 注册请求数据类
 */
data class RegisterRequest(
    val username: String,
    val phone: String,
    val password: String,
    val confirmPassword: String,
    val smsCode: String,
    val realName: String? = null,
    val idNumber: String? = null,
    val gender: String? = null,
    val birthday: String? = null
)

/**
 * 发送验证码请求
 */
data class SmsSendRequest(
    val phone: String
)

/**
 * 发送验证码响应
 */
data class SmsSendResponse(
    val phone: String,
    val smsCode: String,
    val expiresInSeconds: Int
)

/**
 * 登录请求数据类
 */
data class LoginRequest(
    val account: String,
    val password: String? = null,
    val smsCode: String? = null
)

/**
 * 认证成功返回结果
 */
data class AuthResponse(
    val userId: String,
    val username: String,
    val phone: String?,
    val role: String,
    val token: String
)

/**
 * 用户概要
 */
data class UserSummary(
    val id: String,
    val username: String,
    val role: String
)

/**
 * 完整用户信息响应 (Admin/User Profile)
 */
data class UserResponse(
    val id: String,
    val username: String,
    val phone: String,
    val realName: String?,
    val idNumber: String?,
    val gender: String?,
    val birthday: String?,
    val role: String,
    val status: String,
    val createdAt: String?
)

/**
 * 景点响应
 */
data class LandscapeResponse(
    val id: String,
    val title: String,
    val content: String,
    val address: String,
    val latitude: Double?,
    val longitude: Double?,
    val contactPhone: String?,
    val openingTime: String?,
    val level: String?,
    val status: String,
    val auditRemark: String?,
    val publishedAt: String?,
    val auditedAt: String?,
    val creator: UserSummary?
)

/**
 * 景点新建/修改请求
 */
data class LandscapeRequest(
    val title: String? = null,
    val content: String? = null,
    val address: String? = null,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val contactPhone: String? = null,
    val openingTime: String? = null,
    val level: String? = null
)

/**
 * 帖子响应
 */
data class PostResponse(
    val id: String,
    val title: String,
    val tag: String?,
    val content: String,
    val imageUrls: List<String>?,
    val status: String,
    val auditRemark: String?,
    val publishedAt: String?,
    val auditedAt: String?,
    val landscapeId: String?,
    val author: UserSummary?
)

/**
 * 帖子新建请求
 */
data class PostRequest(
    val landscapeId: String? = null,
    val title: String,
    val tag: String? = null,
    val content: String,
    val imageUrls: List<String>? = null
)

/**
 * 评论响应
 */
data class CommentResponse(
    val id: String,
    val content: String,
    val targetType: String,
    val status: String,
    val auditRemark: String?,
    val publishedAt: String?,
    val auditedAt: String?,
    val landscapeId: String?,
    val postId: String?,
    val author: UserSummary?
)

/**
 * 发表评论请求
 */
data class CommentRequest(
    val landscapeId: String? = null,
    val postId: String? = null,
    val content: String
)

/**
 * 互动请求 (收藏/点赞)
 */
data class InteractionRequest(
    val targetType: String, // LANDSCAPE, POST
    val landscapeId: String? = null,
    val postId: String? = null,
    val linkUrl: String? = null
)

/**
 * 互动响应
 */
data class InteractionResponse(
    val id: String,
    val targetType: String,
    val landscapeId: String?,
    val postId: String?,
    val linkUrl: String?
)

/**
 * 地理编码请求
 */
data class GeocodeRequest(
    val address: String
)

/**
 * 地理编码返回结果
 */
data class GeocodeResponse(
    val address: String,
    val latitude: Double,
    val longitude: Double,
    val provider: String
)

/**
 * 审核请求
 */
data class AuditRequest(
    val approved: Boolean,
    val remark: String? = null
)
