package com.example.travel

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.travel.ui.theme.TravelTheme

class ScenicSearchActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TravelTheme {
                Column(modifier = Modifier.fillMaxSize()) {
                    // 顶部导航
                    ScenicSearchTopNavBar()
                    // 景点查询内容
                    ScenicSearchContent()
                }
            }
        }
    }
}

// 顶部导航
@Composable
fun ScenicSearchTopNavBar() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF1A56DB))
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // 左侧：系统名称
        Text(
            text = "旅游书",
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )

        // 中间：导航栏
        Row(
            horizontalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            Text(
                text = "首页",
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "推荐帖",
                color = Color(0xFFE0EFFF),
                fontSize = 16.sp
            )
            Text(
                text = "我的",
                color = Color(0xFFE0EFFF),
                fontSize = 16.sp
            )
        }

        // 右侧：操作按钮和用户标识
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Button(
                onClick = { /* 发布景点逻辑 */ },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50))
            ) {
                Text("发布景点", fontSize = 14.sp)
            }
            Text(
                text = "杨",
                color = Color.White,
                fontSize = 14.sp
            )
        }
    }
}

// 景点查询内容
@Composable
fun ScenicSearchContent() {
    val searchText = remember { mutableStateOf("南京") }
    val sortBy = remember { mutableStateOf("热门优先") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        // 查询筛选区
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 搜索框
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = searchText.value,
                    onValueChange = { searchText.value = it },
                    placeholder = { Text("搜索景点名称") },
                    modifier = Modifier.weight(2f),
                    shape = RoundedCornerShape(8.dp)
                )
                Button(
                    onClick = { /* 搜索逻辑 */ },
                    modifier = Modifier.weight(0.5f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1A56DB))
                ) {
                    Text("搜索")
                }
            }

            // 筛选条件
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // 地点筛选
                Box(
                    modifier = Modifier
                        .background(Color(0xFFE3F2FD), RoundedCornerShape(16.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text("地点：南京市", fontSize = 12.sp, color = Color(0xFF1A56DB))
                }

                // 等级筛选
                Box(
                    modifier = Modifier
                        .background(Color(0xFFE3F2FD), RoundedCornerShape(16.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text("等级：AAAAA（5A景区）", fontSize = 12.sp, color = Color(0xFF1A56DB))
                }

                // 重置筛选按钮
                OutlinedButton(
                    onClick = { /* 重置筛选逻辑 */ },
                    modifier = Modifier.padding(start = 8.dp)
                ) {
                    Text("重置筛选", fontSize = 12.sp)
                }
            }

            // 排序选项
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text("排序：", fontSize = 14.sp, color = Color.Gray)

                // 热门优先
                Box(
                    modifier = Modifier
                        .background(if (sortBy.value == "热门优先") Color(0xFF1A56DB) else Color.Transparent,
                            RoundedCornerShape(16.dp))
                        .border(1.dp, Color(0xFF1A56DB), RoundedCornerShape(16.dp))
                        .clickable { sortBy.value = "热门优先" }
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Text(
                        "热门优先",
                        fontSize = 12.sp,
                        color = if (sortBy.value == "热门优先") Color.White else Color(0xFF1A56DB)
                    )
                }

                // 最新发布
                Box(
                    modifier = Modifier
                        .background(if (sortBy.value == "最新发布") Color(0xFF1A56DB) else Color.Transparent,
                            RoundedCornerShape(16.dp))
                        .border(1.dp, Color(0xFF1A56DB), RoundedCornerShape(16.dp))
                        .clickable { sortBy.value = "最新发布" }
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Text(
                        "最新发布",
                        fontSize = 12.sp,
                        color = if (sortBy.value == "最新发布") Color.White else Color(0xFF1A56DB)
                    )
                }

                // 等级排序
                Box(
                    modifier = Modifier
                        .background(if (sortBy.value == "等级排序") Color(0xFF1A56DB) else Color.Transparent,
                            RoundedCornerShape(16.dp))
                        .border(1.dp, Color(0xFF1A56DB), RoundedCornerShape(16.dp))
                        .clickable { sortBy.value = "等级排序" }
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Text(
                        "等级排序",
                        fontSize = 12.sp,
                        color = if (sortBy.value == "等级排序") Color.White else Color(0xFF1A56DB)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 景点列表
        ScenicSearchList()
    }
}

// 景点数据类
data class ScenicSearch(
    val name: String,
    val description: String,
    val location: String,
    val level: String,
    val publishTime: String,
    val imageUrl: String,
    var isFavorite: Boolean = false
)

// 景点列表
@Composable
fun ScenicSearchList() {
    val scenics = remember {
        mutableStateOf(listOf(
            ScenicSearch(
                "南京夫子庙",
                "秦淮风光带核心景区",
                "南京市秦淮区",
                "AAAAA级景区",
                "2025-11-10",
                "https://bkimg.cdn.bcebos.com/pic/908fa0ec08fa513d26977303d33442fbb2fb421673ee?x-bce-process=image/format,f_auto/quality,Q_70/resize,m_lfit,limit_1,w_536"
            ),
            ScenicSearch(
                "南京中山陵",
                "国家重点文物保护单位",
                "南京市玄武区",
                "AAAAA级景区",
                "2025-11-05",
                "https://baike.baidu.com/pic/%E5%8D%97%E4%BA%AC%E5%A4%AB%E5%AD%90%E5%BA%99/510169/0/0ff41bd5ad6eddc4152404b037dbb6fd536633bd?fr=lemma&fromModule=lemma_content-image"
            ),
            ScenicSearch(
                "南京明孝陵",
                "明清皇家陵寝之首",
                "南京市玄武区",
                "AAAAA级景区",
                "2025-11-15",
                "https://img0.baidu.com/it/u=3156394753,424382676&fm=253&fmt=auto&app=138&f=JPEG?w=800&h=500"
            )
        ))
    }

    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        items(scenics.value) { scenic ->
            ScenicSearchItem(
                scenic = scenic,
                onFavoriteClick = {
                    val updatedScenics = scenics.value.map {
                        if (it.name == scenic.name) it.copy(isFavorite = !it.isFavorite) else it
                    }
                    scenics.value = updatedScenics
                }
            )
        }
    }
}

// 景点查询项组件
@Composable
fun ScenicSearchItem(scenic: ScenicSearch, onFavoriteClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(4.dp),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column {
            // 景点图片
            AsyncImage(
                model = scenic.imageUrl,
                contentDescription = scenic.name,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
            )

            // 景点内容
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                // 景点名称和收藏按钮
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = scenic.name,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = scenic.description,
                            fontSize = 14.sp,
                            color = Color.Gray,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }

                    // 收藏按钮
                    IconButton(onClick = onFavoriteClick) {
                        Icon(
                            imageVector = if (scenic.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "收藏",
                            tint = if (scenic.isFavorite) Color.Red else Color.Gray
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // 景点信息
                Column(
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "地点：${scenic.location}",
                        fontSize = 14.sp,
                        color = Color.Gray
                    )
                    Text(
                        text = "等级：${scenic.level}",
                        fontSize = 14.sp,
                        color = Color.Gray
                    )
                    Text(
                        text = "发布时间：${scenic.publishTime}",
                        fontSize = 14.sp,
                        color = Color.Gray
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // 操作按钮
                Row(
                    horizontalArrangement = Arrangement.End,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // 查看详情按钮
                    Button(
                        onClick = { /* 查看详情逻辑 */ },
                        modifier = Modifier.padding(end = 8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1A56DB))
                    ) {
                        Text("查看详情")
                    }

                    // 收藏按钮（大按钮）
                    OutlinedButton(
                        onClick = onFavoriteClick
                    ) {
                        Icon(
                            imageVector = if (scenic.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "收藏",
                            tint = if (scenic.isFavorite) Color.Red else Color.Gray,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (scenic.isFavorite) "已收藏" else "收藏")
                    }
                }
            }
        }
    }
}

// 预览函数
@Preview(showBackground = true, showSystemUi = true)
@Composable
fun ScenicSearchPreview() {
    TravelTheme {
        Column(modifier = Modifier.fillMaxSize()) {
            ScenicSearchTopNavBar()
            ScenicSearchContent()
        }
    }
}