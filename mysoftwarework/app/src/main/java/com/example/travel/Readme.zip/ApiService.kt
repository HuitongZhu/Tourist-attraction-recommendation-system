package com.example.travel

import retrofit2.http.*

interface ApiService {
    // --- 认证模块 ---
    @POST("api/auth/register")
    suspend fun register(@Body request: RegisterRequest): ApiResponse<AuthResponse>

    @POST("api/auth/login")
    suspend fun login(@Body request: LoginRequest): ApiResponse<AuthResponse>
    
    // 发送短信验证码
    @POST("api/auth/sms/send")
    suspend fun sendSms(@Body request: SmsSendRequest): ApiResponse<SmsSendResponse>

    // --- 景点模块 ---
    @POST("api/landscapes")
    suspend fun createLandscape(@Body request: LandscapeRequest): ApiResponse<LandscapeResponse>

    @GET("api/landscapes")
    suspend fun getLandscapes(
        @Query("keyword") keyword: String? = null,
        @Query("status") status: String? = null,
        @Query("page") page: Int = 0,
        @Query("size") size: Int = 10
    ): ApiResponse<PageResponse<LandscapeResponse>>

    @GET("api/landscapes/{id}")
    suspend fun getLandscapeById(@Path("id") id: String): ApiResponse<LandscapeResponse>

    @PUT("api/landscapes/{id}")
    suspend fun updateLandscape(@Path("id") id: String, @Body request: LandscapeRequest): ApiResponse<LandscapeResponse>

    @DELETE("api/landscapes/{id}")
    suspend fun deleteLandscape(@Path("id") id: String): ApiResponse<Unit>

    // --- 帖子模块 ---
    @POST("api/posts")
    suspend fun createPost(@Body request: PostRequest): ApiResponse<PostResponse>

    @GET("api/posts")
    suspend fun getPosts(
        @Query("keyword") keyword: String? = null,
        @Query("tag") tag: String? = null,
        @Query("status") status: String? = null,
        @Query("landscapeId") landscapeId: String? = null,
        @Query("page") page: Int = 0,
        @Query("size") size: Int = 10
    ): ApiResponse<PageResponse<PostResponse>>

    @GET("api/posts/{id}")
    suspend fun getPostById(@Path("id") id: String): ApiResponse<PostResponse>

    @DELETE("api/posts/{id}")
    suspend fun deletePost(@Path("id") id: String): ApiResponse<Unit>

    // --- 评论模块 ---
    @POST("api/comments")
    suspend fun createComment(@Body request: CommentRequest): ApiResponse<CommentResponse>

    @GET("api/comments")
    suspend fun getComments(
        @Query("landscapeId") landscapeId: String? = null,
        @Query("postId") postId: String? = null,
        @Query("page") page: Int = 0,
        @Query("size") size: Int = 10
    ): ApiResponse<PageResponse<CommentResponse>>

    @DELETE("api/comments/{id}")
    suspend fun deleteComment(@Path("id") id: String): ApiResponse<Unit>

    // --- 点赞收藏模块 ---
    @POST("api/interactions/favorites")
    suspend fun addFavorite(@Body request: InteractionRequest): ApiResponse<InteractionResponse>

    @DELETE("api/interactions/favorites/{id}")
    suspend fun deleteFavorite(@Path("id") id: String): ApiResponse<Unit>

    @POST("api/interactions/likes")
    suspend fun addLike(@Body request: InteractionRequest): ApiResponse<InteractionResponse>

    @DELETE("api/interactions/likes/{id}")
    suspend fun deleteLike(@Path("id") id: String): ApiResponse<Unit>

    // --- 用户模块 (补充) ---
    @GET("api/users/me")
    suspend fun getCurrentUser(): ApiResponse<UserResponse>

    @PUT("api/users/profile")
    suspend fun updateProfile(@Body request: RegisterRequest): ApiResponse<Unit>

    // --- 管理员用户管理 (补充) ---
    @GET("api/admin/users")
    suspend fun getAllUsers(
        @Query("keyword") keyword: String? = null,
        @Query("page") page: Int = 0,
        @Query("size") size: Int = 100
    ): ApiResponse<PageResponse<UserResponse>>

    @PUT("api/admin/users/{id}/status")
    suspend fun updateUserStatus(
        @Path("id") id: String,
        @Query("status") status: String
    ): ApiResponse<Unit>

    @DELETE("api/admin/users/{id}")
    suspend fun deleteUser(@Path("id") id: String): ApiResponse<Unit>

    // --- 地图模块 ---
    @GET("api/maps/geocode")
    suspend fun geocode(@Query("address") address: String): ApiResponse<GeocodeResponse>

    @POST("api/maps/geocode")
    suspend fun geocodePost(@Body request: GeocodeRequest): ApiResponse<GeocodeResponse>

    // --- 管理员审核模块 ---
    @GET("api/admin/pending/landscapes")
    suspend fun getPendingLandscapes(
        @Query("page") page: Int = 0,
        @Query("size") size: Int = 10
    ): ApiResponse<PageResponse<LandscapeResponse>>

    @GET("api/admin/pending/posts")
    suspend fun getPendingPosts(
        @Query("page") page: Int = 0,
        @Query("size") size: Int = 10
    ): ApiResponse<PageResponse<PostResponse>>

    @GET("api/admin/pending/comments")
    suspend fun getPendingComments(
        @Query("page") page: Int = 0,
        @Query("size") size: Int = 10
    ): ApiResponse<PageResponse<CommentResponse>>

    @PATCH("api/admin/landscapes/{id}/audit")
    suspend fun auditLandscape(@Path("id") id: String, @Body request: AuditRequest): ApiResponse<Unit>

    @PATCH("api/admin/posts/{id}/audit")
    suspend fun auditPost(@Path("id") id: String, @Body request: AuditRequest): ApiResponse<Unit>

    @PATCH("api/admin/comments/{id}/audit")
    suspend fun auditComment(@Path("id") id: String, @Body request: AuditRequest): ApiResponse<Unit>
}
