package com.example.travel

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.travel.ui.theme.TravelTheme

class HomeActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TravelTheme {
                var scenicSpots by remember { mutableStateOf<List<LandscapeResponse>>(emptyList()) }
                var isLoading by remember { mutableStateOf(true) }

                LaunchedEffect(Unit) {
                    try {
                        val response = NetworkClient.apiService.getLandscapes(status = "审核通过")
                        if (response.success) {
                            scenicSpots = response.data?.content ?: emptyList()
                        }
                    } catch (e: Exception) {
                        Toast.makeText(this@HomeActivity, "网络连接失败", Toast.LENGTH_SHORT).show()
                    } finally {
                        isLoading = false
                    }
                }

                Column(modifier = Modifier.fillMaxSize()) {
                    TopNavBar(
                        currentPage = PageType.HOME,
                        onPageChange = { page ->
                            when (page) {
                                PageType.RECOMMEND -> startActivity(Intent(this@HomeActivity, RecommendPostActivity::class.java))
                                PageType.PUBLISH_SCENIC -> startActivity(Intent(this@HomeActivity, PublishScenicInfoActivity::class.java))
                                PageType.PUBLISH_POST -> startActivity(Intent(this@HomeActivity, PublishPostActivity::class.java))
                                PageType.PERSONAL -> startActivity(Intent(this@HomeActivity, PersonalHomeActivity::class.java))
                                else -> {}
                            }
                        }
                    )

                    if (isLoading) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator()
                        }
                    } else {
                        HomeScreen(scenicSpots)
                    }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(spots: List<LandscapeResponse>) {
    val context = LocalContext.current
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        items(spots) { spot ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        val intent = Intent(context, ScenicDetailActivity::class.java)
                        intent.putExtra("landscapeId", spot.id)
                        context.startActivity(intent)
                    },
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Column {
                    AsyncImage(
                        model = "https://via.placeholder.com/400x200.png?text=${spot.title}",
                        contentDescription = spot.title,
                        modifier = Modifier.fillMaxWidth().height(200.dp)
                    )
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(text = spot.title, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text(text = "地点：${spot.address}", fontSize = 12.sp, color = Color.Gray)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = spot.content, fontSize = 14.sp, maxLines = 2)
                    }
                }
            }
        }
    }
}
