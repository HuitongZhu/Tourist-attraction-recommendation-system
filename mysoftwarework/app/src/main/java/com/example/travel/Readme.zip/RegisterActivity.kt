package com.example.travel

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.example.travel.ui.theme.TravelTheme
import kotlinx.coroutines.launch

class RegisterActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TravelTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    RegisterScreen(
                        modifier = Modifier.padding(innerPadding),
                        onLoginClick = { finish() },
                        onRegisterClick = { regData ->
                            lifecycleScope.launch {
                                try {
                                    val response = NetworkClient.apiService.register(regData)
                                    if (response.success) {
                                        Toast.makeText(this@RegisterActivity, "注册成功", Toast.LENGTH_SHORT).show()
                                        finish()
                                    } else {
                                        Toast.makeText(this@RegisterActivity, "失败: ${response.message}", Toast.LENGTH_LONG).show()
                                    }
                                } catch (e: Exception) {
                                    Toast.makeText(this@RegisterActivity, "网络连接失败", Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        onSendSmsClick = { phone ->
                            if (phone.isEmpty()) {
                                Toast.makeText(this@RegisterActivity, "请输入手机号", Toast.LENGTH_SHORT).show()
                                return@RegisterScreen
                            }
                            lifecycleScope.launch {
                                try {
                                    val response = NetworkClient.apiService.sendSms(SmsSendRequest(phone))
                                    if (response.success && response.data != null) {
                                        Toast.makeText(this@RegisterActivity, "验证码: ${response.data.smsCode}", Toast.LENGTH_LONG).show()
                                    } else {
                                        Toast.makeText(this@RegisterActivity, "发送失败: ${response.message}", Toast.LENGTH_SHORT).show()
                                    }
                                } catch (e: Exception) {
                                    Toast.makeText(this@RegisterActivity, "网络异常", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun RegisterScreen(
    modifier: Modifier = Modifier,
    onLoginClick: () -> Unit,
    onRegisterClick: (RegisterRequest) -> Unit,
    onSendSmsClick: (String) -> Unit
) {
    var username by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var smsCode by remember { mutableStateOf("") }
    var realName by remember { mutableStateOf("") }
    var idNumber by remember { mutableStateOf("") }
    var gender by remember { mutableStateOf("") }
    var birthday by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(modifier = Modifier.fillMaxWidth().height(50.dp).background(Color(0xFF1A56DB)))
        
        Spacer(modifier = Modifier.height(30.dp))
        Text("账号注册", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1A56DB))
        Text("请填写以下信息完成注册", fontSize = 14.sp, color = Color.Gray)

        Spacer(modifier = Modifier.height(30.dp))

        // 基础必填信息
        SectionTitle("基础账号信息")
        CustomRegisterField(value = username, onValueChange = { username = it }, label = "用户名 (必填)")
        CustomRegisterField(value = phone, onValueChange = { phone = it }, label = "手机号 (必填)", keyboardType = KeyboardType.Phone)
        
        Row(
            modifier = Modifier.fillMaxWidth(0.8f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = smsCode,
                onValueChange = { smsCode = it },
                label = { Text("验证码") },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Button(
                onClick = { onSendSmsClick(phone) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1A56DB)),
                modifier = Modifier.height(56.dp)
            ) {
                Text("获取验证码", fontSize = 12.sp)
            }
        }

        CustomRegisterField(value = password, onValueChange = { password = it }, label = "密码 (必填)", isPassword = true)
        CustomRegisterField(value = confirmPassword, onValueChange = { confirmPassword = it }, label = "确认密码", isPassword = true)

        Spacer(modifier = Modifier.height(20.dp))
        
        // 个人详细资料 (选填)
        SectionTitle("个人详细资料 (选填)")
        CustomRegisterField(value = realName, onValueChange = { realName = it }, label = "真实姓名")
        CustomRegisterField(value = idNumber, onValueChange = { idNumber = it }, label = "身份证号")
        CustomRegisterField(value = gender, onValueChange = { gender = it }, label = "性别 (男/女)")
        CustomRegisterField(value = birthday, onValueChange = { birthday = it }, label = "生日 (YYYY-MM-DD)")

        Spacer(modifier = Modifier.height(30.dp))

        Button(
            onClick = {
                if (username.isEmpty() || phone.isEmpty() || password.isEmpty() || smsCode.isEmpty() || confirmPassword.isEmpty()) {
                    return@Button
                }
                if (password != confirmPassword) {
                    return@Button
                }
                onRegisterClick(
                    RegisterRequest(
                        username = username,
                        phone = phone,
                        password = password,
                        confirmPassword = confirmPassword,
                        smsCode = smsCode,
                        realName = realName.ifEmpty { null },
                        idNumber = idNumber.ifEmpty { null },
                        gender = gender.ifEmpty { null },
                        birthday = birthday.ifEmpty { null }
                    )
                )
            },
            modifier = Modifier.fillMaxWidth(0.8f).height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1A56DB)),
            shape = RoundedCornerShape(25.dp)
        ) {
            Text("立即注册", fontSize = 18.sp)
        }

        TextButton(onClick = onLoginClick) {
            Text("已有账号？返回登录", color = Color(0xFF1A56DB))
        }
        
        Spacer(modifier = Modifier.height(40.dp))
    }
}

@Composable
fun SectionTitle(title: String) {
    Row(modifier = Modifier.fillMaxWidth(0.8f).padding(vertical = 8.dp)) {
        Text(text = title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.DarkGray)
    }
}

@Composable
fun CustomRegisterField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    isPassword: Boolean = false,
    keyboardType: KeyboardType = KeyboardType.Text
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        visualTransformation = if (isPassword) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        modifier = Modifier.fillMaxWidth(0.8f).padding(vertical = 6.dp),
        singleLine = true,
        shape = RoundedCornerShape(12.dp)
    )
}
